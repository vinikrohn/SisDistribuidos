/**
 * Modulo 1 - Exercicio 1: Sistema de Caixa Centralizado de Evento (padrao MVC)
 *
 * 5 caixas (threads) vendem fichas simultaneamente, todos atualizando
 * o mesmo saldo bancario centralizado do evento.
 *
 * Cada caixa vende 1.000 fichas de R$ 10,00 -> saldo final esperado: R$ 50.000,00
 *
 * Avalia: uso de ReentrantLock para garantir exclusao mutua sobre o
 * recurso compartilhado (saldoCentral), evitando condicao de corrida.
 */

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

// ==================== MODEL ====================
class CaixaCentralModel {
    private double saldoCentral = 0.0;
    private final Lock lock = new ReentrantLock(); // protege o recurso compartilhado

    private final int numCaixas;
    private final int fichasPorCaixa;
    private final double precoFicha;

    public CaixaCentralModel(int numCaixas, int fichasPorCaixa, double precoFicha) {
        this.numCaixas = numCaixas;
        this.fichasPorCaixa = fichasPorCaixa;
        this.precoFicha = precoFicha;
    }

    /** Executado por cada thread (caixa). Atualiza o saldo compartilhado. */
    private void venderFichas() {
        for (int i = 0; i < fichasPorCaixa; i++) {
            lock.lock();
            try {
                saldoCentral += precoFicha;
            } finally {
                lock.unlock(); // sempre libera o lock, mesmo se der excecao
            }
        }
    }

    /** Cria, inicia e aguarda as threads dos caixas. */
    public double processarVendas() throws InterruptedException {
        Thread[] threads = new Thread[numCaixas];

        for (int i = 0; i < numCaixas; i++) {
            final int idCaixa = i + 1;
            threads[i] = new Thread(() -> {
                System.out.println("[Caixa " + idCaixa + "] iniciando vendas...");
                venderFichas();
                System.out.println("[Caixa " + idCaixa + "] finalizou vendas.");
            });
            threads[i].start();
        }

        for (Thread t : threads) {
            t.join();
        }

        return saldoCentral;
    }

    public double getSaldoEsperado() {
        return numCaixas * fichasPorCaixa * precoFicha;
    }
}

// ==================== VIEW ====================
class CaixaView {
    public void exibirInicio() {
        System.out.println("Iniciando vendas nos 5 caixas do evento...\n");
    }

    public void exibirResultado(double saldoFinal, double saldoEsperado) {
        System.out.printf("%nSaldo final do evento: R$ %,.2f%n", saldoFinal);

        if (saldoFinal == saldoEsperado) {
            System.out.printf("Saldo confere com o esperado (R$ %,.2f)%n", saldoEsperado);
        } else {
            System.out.printf("Saldo incorreto! Esperado R$ %,.2f, houve condicao de corrida.%n",
                    saldoEsperado);
        }
    }
}

// ==================== CONTROLLER ====================
class CaixaController {
    private CaixaCentralModel model;
    private CaixaView view;

    public CaixaController() {
        this.model = new CaixaCentralModel(5, 1000, 10.00);
        this.view = new CaixaView();
    }

    public void executar() throws InterruptedException {
        view.exibirInicio();
        double saldoFinal = model.processarVendas();
        view.exibirResultado(saldoFinal, model.getSaldoEsperado());
    }
}

// ==================== MAIN ====================
public class EventoApp {
    public static void main(String[] args) throws InterruptedException {
        new CaixaController().executar();
    }
}
