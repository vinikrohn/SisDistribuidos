# Relógios Físicos e Lógicos, Exclusão Mútua e Eleição

Pesquisa compilada + exercícios práticos em **POO (Python)** sobre três
temas centrais de Sistemas Distribuídos.

---

## 1. Relógios Físicos e Lógicos

### 1.1 Relógios Físicos

Em um sistema distribuído, cada máquina possui seu próprio relógio de
hardware (cristal de quartzo). Como cristais diferentes oscilam em
frequências ligeiramente distintas, os relógios de máquinas diferentes
**divergem com o tempo** — fenômeno chamado de *clock drift* (deriva de
relógio). Isso torna inviável usar relógios físicos "crus" para
ordenar eventos entre processos de máquinas diferentes.

Para reduzir essa divergência, existem algoritmos de **sincronização
de relógios físicos**, entre os mais conhecidos:

- **Algoritmo de Cristian**: um processo consulta periodicamente um
  servidor de tempo confiável (time server) e ajusta seu relógio
  considerando o atraso de rede estimado (RTT/2).
- **Algoritmo de Berkeley**: um processo coordenador consulta o
  relógio de todas as máquinas, calcula uma média (descartando valores
  muito discrepantes) e envia a cada uma o ajuste necessário — não
  exige um servidor de tempo absolutamente correto.
- **NTP (Network Time Protocol)**: protocolo hierárquico usado na
  prática na Internet, organizado em *strata* (camadas), onde o
  estrato 0 são relógios de referência (atômicos/GPS) e os demais
  sincronizam recursivamente a partir deles.

No projeto (`clocks.py`), a classe `PhysicalClock` simula esse drift de
forma simplificada, mostrando como dois relógios que partem
sincronizados divergem após alguns "tiques".

### 1.2 Relógios Lógicos

Como sincronizar relógios físicos com precisão perfeita é impossível,
Leslie Lamport propôs, em 1978, que o que realmente importa em muitos
casos não é o tempo absoluto, mas a **ordem causal dos eventos**
(happens-before). Disso nascem os relógios lógicos:

**Relógio de Lamport**
- Cada processo mantém um único contador inteiro.
- Regras:
  1. Antes de um evento local (incluindo enviar uma mensagem), o
     processo incrementa seu contador.
  2. Toda mensagem enviada carrega o valor do contador (timestamp).
  3. Ao receber uma mensagem, o processo ajusta seu contador para
     `max(contador_local, timestamp_recebido) + 1`.
- Garante que, se um evento A "aconteceu antes" (happens-before) de um
  evento B, então `Lamport(A) < Lamport(B)`. **Mas a recíproca não é
  verdadeira**: dois eventos podem ter timestamps ordenados sem que um
  tenha causado o outro (Lamport não detecta concorrência).

**Relógio Vetorial (Vector Clock)**
- Cada processo mantém um **vetor** com uma posição para cada processo
  do sistema (não apenas um contador escalar).
- Regras semelhantes às de Lamport, mas a atualização ao receber uma
  mensagem é `vetor[i] = max(vetor[i], vetor_recebido[i])` para toda
  posição `i`, seguido de incremento da própria posição.
- Com relógios vetoriais é possível comparar dois eventos e dizer com
  certeza se um causou o outro (`V1 <= V2` em todas as posições) ou se
  eles são **concorrentes** (nenhum vetor domina o outro totalmente) —
  o que o relógio de Lamport sozinho não permite.

No projeto (`clocks.py`), `LamportClock` e `VectorClock` implementam
essas regras, e a função `demo()` simula três processos trocando
mensagens, mostrando a evolução dos dois relógios e uma comparação
final que identifica eventos concorrentes.

---

## 2. Exclusão Mútua Distribuída

Exclusão mútua garante que apenas um processo por vez execute uma
**região crítica** (RC), mesmo sem memória compartilhada. As
abordagens clássicas são:

- **Centralizada**: um processo coordenador central concede permissão
  de entrada na RC. Simples, mas cria um ponto único de falha e
  gargalo.
- **Distribuída — Ricart-Agrawala**: cada processo que quer entrar na
  RC envia um pedido `REQUEST(timestamp)` (usando relógio de Lamport)
  para **todos** os demais e só entra na RC depois de receber `REPLY`
  de todos. Um processo que recebe um pedido só responde
  imediatamente se não estiver competindo pela RC com prioridade maior
  (timestamp menor); caso contrário, adia a resposta até sair da sua
  própria RC. Não há coordenador central nem ponto único de falha,
  mas o custo é `2(n-1)` mensagens por entrada na RC.
- **Anel de Token (Token Ring)**: os processos formam um anel lógico e
  um "token" (bastão) circula continuamente; só quem possui o token
  pode entrar na RC. Simples e livre de starvation, mas a latência
  para conseguir o token pode ser alta em anéis grandes.

No projeto (`mutual_exclusion.py`), a classe `MutexProcess` implementa
o algoritmo de **Ricart-Agrawala** completo (REQUEST / REPLY / adiar
resposta), com processos simulados por threads que só se comunicam por
filas de mensagens (`queue.Queue`), demonstrando dois processos
disputando a região crítica simultaneamente.

---

## 3. Algoritmos de Eleição

Quando o coordenador de um sistema distribuído falha, é preciso eleger
um novo. Dois algoritmos clássicos:

- **Algoritmo do Valentão (Bully)**: quem percebe a falha do
  coordenador envia `ELECTION` a todos os processos com ID **maior**
  que o seu. Se nenhum responder, ele se autoproclama coordenador. Se
  algum responder, aquele (ou o de maior ID entre os que responderam)
  assume a eleição recursivamente, até que o maior ID vivo vença. O
  vencedor anuncia `COORDINATOR` a todos. Rápido, mas gera muitas
  mensagens em cenários de falhas simultâneas.
- **Algoritmo do Anel (Ring)**: os processos formam um anel lógico.
  Quem detecta a falha envia `ELECTION` com seu próprio ID para o
  próximo processo vivo no anel; cada processo adiciona seu ID à
  mensagem e repassa adiante. Quando a mensagem retorna ao iniciador,
  o maior ID coletado é o vencedor, que circula uma mensagem
  `COORDINATOR` pelo anel. Usa menos mensagens no total, mas depende
  de uma topologia de anel bem definida e tolera apenas a falha de nós
  sendo contornada durante o percurso.

No projeto (`election.py`), `BullyElection` e `RingElection`
implementam ambos os algoritmos, incluindo o tratamento de processos
"caídos" (`alive = False`) que devem ser ignorados na eleição.

---

## Como rodar os exercícios

```bash
python3 clocks.py              # Relógio de Lamport + Relógio Vetorial + Relógio Físico
python3 mutual_exclusion.py    # Exclusão mútua distribuída (Ricart-Agrawala)
python3 election.py            # Eleição: Bully e Anel
```

## Estrutura em POO

| Arquivo               | Classes principais                                              |
|------------------------|-------------------------------------------------------------------|
| `clocks.py`            | `PhysicalClock`, `LamportClock`, `VectorClock`, `SimulatedProcess` |
| `mutual_exclusion.py`  | `MutexProcess`, `RequestMsg`, `ReplyMsg`, `MessagePump`            |
| `election.py`          | `BullyProcess`, `BullyElection`, `RingProcess`, `RingElection`     |

## Referências para aprofundamento

- Lamport, L. (1978). *Time, Clocks, and the Ordering of Events in a
  Distributed System*. Communications of the ACM.
- Ricart, G.; Agrawala, A. (1981). *An Optimal Algorithm for Mutual
  Exclusion in Computer Networks*. Communications of the ACM.
- Garcia-Molina, H. (1982). *Elections in a Distributed Computing
  System* (algoritmo Bully). IEEE Transactions on Computers.
- Tanenbaum, A. S.; Van Steen, M. — *Distributed Systems: Principles
  and Paradigms* (capítulos sobre sincronização e coordenação).
- Coulouris, G. et al. — *Distributed Systems: Concepts and Design*.
