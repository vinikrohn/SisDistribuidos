"""
Exclusão Mútua Distribuída - Exercício em POO
================================================

Implementa o algoritmo de RICART-AGRAWALA (baseado em relógios lógicos
de Lamport) para garantir que apenas um processo por vez entre na
região crítica (RC), mesmo sem memória compartilhada nem coordenador
central.

Ideia geral do algoritmo:
1. Quando um processo Pi quer entrar na região crítica, ele envia uma
   mensagem REQUEST(timestamp, Pi) para TODOS os outros processos.
2. Um processo Pj que recebe um REQUEST responde imediatamente com um
   REPLY, EXCETO se:
      a) ele próprio está na região crítica; ou
      b) ele também quer entrar na RC e seu próprio pedido tem
         timestamp menor (ou timestamp igual e ID menor) que o pedido
         recebido — nesse caso ele adia (enfileira) a resposta.
3. Pi entra na região crítica somente depois de receber REPLY de todos
   os outros processos.
4. Ao sair da RC, Pi responde a todos os pedidos que havia adiado.

Esta implementação simula os processos com threads + filas (Queue) para
tornar a demonstração determinística e fácil de rodar em um único
arquivo, mas o modelo de comunicação (apenas troca de mensagens) é o
mesmo de um sistema distribuído real.
"""

from __future__ import annotations
import queue
import threading
import time
from dataclasses import dataclass
from typing import Dict, List


# ----------------------------------------------------------------------
# Mensagens do protocolo
# ----------------------------------------------------------------------
@dataclass
class RequestMsg:
    sender: str
    timestamp: int


@dataclass
class ReplyMsg:
    sender: str


# ----------------------------------------------------------------------
# Processo participante da exclusão mútua
# ----------------------------------------------------------------------
class MutexProcess:
    """
    Um processo que participa do algoritmo de Ricart-Agrawala.

    Cada processo tem sua própria fila de entrada (inbox) e conhece as
    filas de entrada de todos os outros — a única forma de comunicação
    entre eles é colocando mensagens nessas filas.
    """

    def __init__(self, name: str, all_inboxes: Dict[str, "queue.Queue"]):
        self.name = name
        self.all_inboxes = all_inboxes  # nome -> fila de entrada de cada processo
        self.inbox: "queue.Queue" = all_inboxes[name]

        self.lamport_clock = 0
        self.requesting_cs = False
        self.request_timestamp: int | None = None
        self.in_critical_section = False

        self.replies_received: set[str] = set()
        self.deferred_replies: List[str] = []

        self.log: List[str] = []
        self._lock = threading.Lock()

    # -- utilidades ------------------------------------------------------
    def _tick(self) -> int:
        self.lamport_clock += 1
        return self.lamport_clock

    def _log(self, msg: str) -> None:
        self.log.append(f"[t={self.lamport_clock:>2}] [{self.name}] {msg}")

    def _peers(self) -> List[str]:
        return [p for p in self.all_inboxes if p != self.name]

    # -- protocolo ---------------------------------------------------------
    def request_critical_section(self) -> None:
        with self._lock:
            self.requesting_cs = True
            self.request_timestamp = self._tick()
            self.replies_received.clear()

        self._log(f"quer entrar na RC (REQUEST ts={self.request_timestamp})")
        for peer in self._peers():
            self.all_inboxes[peer].put(RequestMsg(sender=self.name, timestamp=self.request_timestamp))

        # espera ativa (com timeout curto) por todas as respostas
        while len(self.replies_received) < len(self._peers()):
            time.sleep(0.01)

        with self._lock:
            self.in_critical_section = True
        self._log(">>> ENTROU NA REGIÃO CRÍTICA <<<")

    def release_critical_section(self) -> None:
        with self._lock:
            self.in_critical_section = False
            self.requesting_cs = False
        self._log("<<< SAIU DA REGIÃO CRÍTICA >>>")

        # responde a todos os pedidos que haviam sido adiados
        for peer in self.deferred_replies:
            self.all_inboxes[peer].put(ReplyMsg(sender=self.name))
            self._log(f"envia REPLY adiado para {peer}")
        self.deferred_replies.clear()

    def handle_messages_once(self) -> None:
        """Processa uma mensagem pendente da inbox, se houver."""
        try:
            msg = self.inbox.get_nowait()
        except queue.Empty:
            return

        if isinstance(msg, RequestMsg):
            self._handle_request(msg)
        elif isinstance(msg, ReplyMsg):
            self._handle_reply(msg)

    def _handle_request(self, msg: RequestMsg) -> None:
        self.lamport_clock = max(self.lamport_clock, msg.timestamp) + 1
        self._log(f"recebeu REQUEST de {msg.sender} (ts={msg.timestamp})")

        should_defer = False
        with self._lock:
            if self.in_critical_section:
                should_defer = True
            elif self.requesting_cs and self.request_timestamp is not None:
                my_priority = (self.request_timestamp, self.name)
                their_priority = (msg.timestamp, msg.sender)
                if my_priority < their_priority:
                    should_defer = True

        if should_defer:
            self.deferred_replies.append(msg.sender)
            self._log(f"ADIA resposta para {msg.sender} (minha prioridade é maior)")
        else:
            self.all_inboxes[msg.sender].put(ReplyMsg(sender=self.name))
            self._log(f"envia REPLY imediato para {msg.sender}")

    def _handle_reply(self, msg: ReplyMsg) -> None:
        self.replies_received.add(msg.sender)
        self._log(f"recebeu REPLY de {msg.sender} ({len(self.replies_received)}/{len(self._peers())})")


class MessagePump(threading.Thread):
    """Thread auxiliar que fica processando as mensagens recebidas por um MutexProcess."""

    def __init__(self, process: MutexProcess, stop_event: threading.Event):
        super().__init__(daemon=True)
        self.process = process
        self.stop_event = stop_event

    def run(self) -> None:
        while not self.stop_event.is_set():
            self.process.handle_messages_once()
            time.sleep(0.005)


def demo() -> None:
    names = ["P1", "P2", "P3"]
    inboxes = {name: queue.Queue() for name in names}
    processes = {name: MutexProcess(name, inboxes) for name in names}

    stop_event = threading.Event()
    pumps = [MessagePump(p, stop_event) for p in processes.values()]
    for pump in pumps:
        pump.start()

    print("=== Demonstração: Exclusão Mútua com Ricart-Agrawala ===")
    print("P1 e P3 disputam a região crítica ao mesmo tempo; P2 entra depois.\n")

    def worker(name: str, delay_before: float, hold_time: float):
        time.sleep(delay_before)
        proc = processes[name]
        proc.request_critical_section()
        time.sleep(hold_time)
        proc.release_critical_section()

    threads = [
        threading.Thread(target=worker, args=("P1", 0.0, 0.1)),
        threading.Thread(target=worker, args=("P3", 0.0, 0.1)),
        threading.Thread(target=worker, args=("P2", 0.05, 0.1)),
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    time.sleep(0.2)
    stop_event.set()

    # imprime os logs intercalados em ordem de relógio lógico aproximada
    all_entries = []
    for proc in processes.values():
        all_entries.extend(proc.log)
    for entry in all_entries:
        print(entry)


if __name__ == "__main__":
    demo()
