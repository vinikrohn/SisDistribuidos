"""
Relógios Físicos e Lógicos - Exercícios em POO
================================================

Este módulo implementa e demonstra:

1. Relógio Físico (simulado): cada processo tem um relógio de hardware
   com deriva (drift), ilustrando por que relógios físicos de máquinas
   diferentes não ficam naturalmente sincronizados.

2. Relógio Lógico de Lamport: ordena eventos causalmente (happens-before)
   usando um único contador inteiro por processo.

3. Relógio Vetorial (Vector Clock): estende o relógio de Lamport para
   detectar quando dois eventos são CONCORRENTES (nenhum causa o outro),
   algo que o relógio de Lamport sozinho não consegue determinar.

Cada conceito é modelado como uma classe, e um "Process" simulado troca
mensagens entre si para demonstrar o funcionamento na prática.
"""

from __future__ import annotations
import random
from dataclasses import dataclass, field
from typing import Dict, List


# ----------------------------------------------------------------------
# 1) Relógio Físico simulado
# ----------------------------------------------------------------------
class PhysicalClock:
    """
    Simula um relógio de hardware sujeito a deriva (clock drift).

    Cada tique real do sistema avança o relógio de `1 + drift` unidades,
    onde `drift` é um pequeno erro característico daquele processo.
    Isso ilustra por que, sem sincronização (ex.: NTP, algoritmo de
    Cristian, algoritmo de Berkeley), relógios físicos de máquinas
    diferentes divergem ao longo do tempo.
    """

    def __init__(self, process_name: str, drift: float = 0.0, start_time: float = 0.0):
        self.process_name = process_name
        self.drift = drift
        self.time = start_time

    def tick(self, real_elapsed: float = 1.0) -> float:
        self.time += real_elapsed * (1.0 + self.drift)
        return self.time

    def read(self) -> float:
        return self.time


# ----------------------------------------------------------------------
# 2) Relógio Lógico de Lamport
# ----------------------------------------------------------------------
class LamportClock:
    """
    Implementa as regras clássicas do relógio lógico de Lamport:

    R1: antes de cada evento local (ou de enviar uma mensagem),
        o processo incrementa seu relógio: C = C + 1.
    R2: ao enviar uma mensagem, o processo anexa seu relógio (timestamp).
    R3: ao receber uma mensagem com timestamp Tm, o processo faz
        C = max(C, Tm) + 1.
    """

    def __init__(self):
        self._time = 0

    @property
    def time(self) -> int:
        return self._time

    def local_event(self) -> int:
        """Regra R1: evento interno do processo."""
        self._time += 1
        return self._time

    def send_event(self) -> int:
        """Regra R1 + R2: incrementa e retorna o timestamp a ser enviado."""
        self._time += 1
        return self._time

    def receive_event(self, incoming_timestamp: int) -> int:
        """Regra R3: sincroniza com o timestamp recebido."""
        self._time = max(self._time, incoming_timestamp) + 1
        return self._time


# ----------------------------------------------------------------------
# 3) Relógio Vetorial
# ----------------------------------------------------------------------
class VectorClock:
    """
    Relógio vetorial: cada processo mantém um vetor com uma entrada por
    processo do sistema. Permite comparar dois eventos e determinar se
    um "aconteceu antes" do outro (happens-before) ou se são
    concorrentes.
    """

    def __init__(self, process_id: str, all_process_ids: List[str]):
        self.process_id = process_id
        self.vector: Dict[str, int] = {pid: 0 for pid in all_process_ids}

    def local_event(self) -> Dict[str, int]:
        self.vector[self.process_id] += 1
        return dict(self.vector)

    def send_event(self) -> Dict[str, int]:
        self.vector[self.process_id] += 1
        return dict(self.vector)

    def receive_event(self, incoming_vector: Dict[str, int]) -> Dict[str, int]:
        for pid, value in incoming_vector.items():
            self.vector[pid] = max(self.vector.get(pid, 0), value)
        self.vector[self.process_id] += 1
        return dict(self.vector)

    @staticmethod
    def happens_before(v1: Dict[str, int], v2: Dict[str, int]) -> bool:
        """v1 -> v2 (v1 aconteceu antes de v2) se v1 <= v2 em todas as
        posições e v1 < v2 em pelo menos uma."""
        keys = set(v1) | set(v2)
        le_all = all(v1.get(k, 0) <= v2.get(k, 0) for k in keys)
        lt_one = any(v1.get(k, 0) < v2.get(k, 0) for k in keys)
        return le_all and lt_one

    @classmethod
    def compare(cls, v1: Dict[str, int], v2: Dict[str, int]) -> str:
        if v1 == v2:
            return "IGUAIS"
        if cls.happens_before(v1, v2):
            return "V1 -> V2 (V1 aconteceu antes)"
        if cls.happens_before(v2, v1):
            return "V2 -> V1 (V2 aconteceu antes)"
        return "CONCORRENTES (nenhum causou o outro)"


# ----------------------------------------------------------------------
# Simulação demonstrativa
# ----------------------------------------------------------------------
@dataclass
class SimulatedMessage:
    sender: str
    lamport_ts: int
    vector_ts: Dict[str, int]
    content: str


class SimulatedProcess:
    """Processo simulado que possui um relógio de Lamport e um vetorial."""

    def __init__(self, name: str, all_process_ids: List[str]):
        self.name = name
        self.lamport = LamportClock()
        self.vector = VectorClock(name, all_process_ids)
        self.log: List[str] = []

    def do_local_work(self) -> None:
        lt = self.lamport.local_event()
        vt = self.vector.local_event()
        self.log.append(f"[{self.name}] evento local -> Lamport={lt} Vetor={vt}")

    def send(self, content: str) -> SimulatedMessage:
        lt = self.lamport.send_event()
        vt = self.vector.send_event()
        self.log.append(f"[{self.name}] ENVIA '{content}' -> Lamport={lt} Vetor={vt}")
        return SimulatedMessage(sender=self.name, lamport_ts=lt, vector_ts=vt, content=content)

    def receive(self, msg: SimulatedMessage) -> None:
        lt = self.lamport.receive_event(msg.lamport_ts)
        vt = self.vector.receive_event(msg.vector_ts)
        self.log.append(
            f"[{self.name}] RECEBE '{msg.content}' de {msg.sender} -> Lamport={lt} Vetor={vt}"
        )


def demo() -> None:
    ids = ["P1", "P2", "P3"]
    p1, p2, p3 = (SimulatedProcess(pid, ids) for pid in ids)

    print("=== Demonstração: Relógio Lógico de Lamport + Relógio Vetorial ===\n")

    p1.do_local_work()
    m1 = p1.send("ola de P1")
    p2.do_local_work()
    p2.receive(m1)
    m2 = p2.send("resposta de P2")
    p3.do_local_work()
    p3.receive(m2)
    p1.do_local_work()

    for proc in (p1, p2, p3):
        for entry in proc.log:
            print(entry)

    print("\n--- Comparação de dois eventos com relógio vetorial ---")
    v_evento_p1 = p1.vector.vector
    v_evento_p3 = p3.vector.vector
    print(f"Vetor final P1: {v_evento_p1}")
    print(f"Vetor final P3: {v_evento_p3}")
    print("Relação:", VectorClock.compare(v_evento_p1, v_evento_p3))

    print("\n=== Demonstração: Relógio Físico com deriva (drift) ===")
    clock_a = PhysicalClock("Maquina-A", drift=0.0)
    clock_b = PhysicalClock("Maquina-B", drift=0.02)  # 2% mais rápido
    for _ in range(10):
        clock_a.tick()
        clock_b.tick()
    print(f"Maquina-A após 10 tiques: {clock_a.read():.3f}")
    print(f"Maquina-B após 10 tiques: {clock_b.read():.3f} (divergiu por causa do drift)")


if __name__ == "__main__":
    demo()
