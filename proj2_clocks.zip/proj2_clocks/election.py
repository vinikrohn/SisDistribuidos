"""
Algoritmos de Eleição - Exercício em POO
===========================================

Implementa dois algoritmos clássicos de eleição de coordenador em
sistemas distribuídos:

1. ALGORITMO DO VALENTÃO (Bully Algorithm)
   - Qualquer processo que perceba que o coordenador caiu inicia uma
     eleição enviando ELECTION para todos os processos com ID MAIOR
     que o seu.
   - Se ninguém com ID maior responder, ele se autoproclama
     coordenador e avisa a todos (COORDINATOR).
   - Se alguém com ID maior responder (OK), o processo desiste e
     espera o novo coordenador se anunciar.

2. ALGORITMO DO ANEL (Ring Algorithm)
   - Os processos são organizados logicamente em um anel.
   - Quem percebe a falha do coordenador envia uma mensagem ELECTION
     contendo seu próprio ID para o próximo processo vivo no anel.
   - Cada processo, ao repassar, insere seu próprio ID na mensagem caso
     ainda não esteja lá; quando a mensagem volta ao remetente
     original, o processo com MAIOR ID entre os coletados vence.
   - O vencedor circula uma mensagem COORDINATOR pelo anel.

Ambos são modelados com classes que representam processos e trocam
mensagens apenas por meio de estruturas explícitas (filas / listas),
sem nenhuma variável global compartilhada.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ------------------------------------------------------------------
# ALGORITMO DO VALENTÃO (BULLY)
# ------------------------------------------------------------------
class BullyProcess:
    """Um processo participante do algoritmo Bully."""

    def __init__(self, process_id: int, alive: bool = True):
        self.process_id = process_id
        self.alive = alive
        self.coordinator_id: Optional[int] = None
        self.log: List[str] = []

    def _log(self, msg: str) -> None:
        self.log.append(f"[P{self.process_id}] {msg}")


class BullyElection:
    """
    Coordena a simulação do algoritmo Bully entre um conjunto de
    processos. O maior ID entre os processos vivos sempre vence.
    """

    def __init__(self, processes: List[BullyProcess]):
        self.processes: Dict[int, BullyProcess] = {p.process_id: p for p in processes}

    def _higher_alive(self, process_id: int) -> List[BullyProcess]:
        return [p for p in self.processes.values() if p.process_id > process_id and p.alive]

    def start_election(self, initiator_id: int) -> int:
        """
        Executa uma eleição completa iniciada por `initiator_id` e
        retorna o ID do novo coordenador.
        """
        initiator = self.processes[initiator_id]
        initiator._log(f"detectou falha do coordenador e inicia ELEIÇÃO")

        candidates = self._election_round(initiator_id)
        winner_id = max(candidates) if candidates else initiator_id
        winner = self.processes[winner_id]

        for p in self.processes.values():
            if p.alive:
                p.coordinator_id = winner_id
        winner._log(f"é o NOVO COORDENADOR (maior ID vivo) -> anuncia COORDINATOR a todos")
        for p in self.processes.values():
            if p.alive and p.process_id != winner_id:
                p._log(f"recebeu anúncio: novo coordenador é P{winner_id}")

        return winner_id

    def _election_round(self, starter_id: int) -> List[int]:
        """
        Simula recursivamente: starter manda ELECTION para todos com ID
        maior e vivos. Se algum responder, ele mesmo inicia sua própria
        rodada de eleição (regra do Bully). Retorna a lista de IDs que
        efetivamente participaram e estão aptos a virar coordenador.
        """
        starter = self.processes[starter_id]
        higher = self._higher_alive(starter_id)

        if not higher:
            starter._log("nenhum processo vivo com ID maior -> pode se tornar coordenador")
            return [starter_id]

        ids_reached = []
        for p in higher:
            starter._log(f"envia ELECTION para P{p.process_id}")
            p._log(f"respondeu OK a P{starter_id} e assume a eleição")
            # cada processo que responde OK, por regra do Bully, inicia
            # sua própria eleição (pode recursar até o maior vivo)
            ids_reached.extend(self._election_round(p.process_id))

        return ids_reached


# ------------------------------------------------------------------
# ALGORITMO DO ANEL (RING)
# ------------------------------------------------------------------
@dataclass
class RingElectionMessage:
    ids_collected: List[int] = field(default_factory=list)
    is_coordinator_announcement: bool = False
    winner_id: Optional[int] = None


class RingProcess:
    def __init__(self, process_id: int, alive: bool = True):
        self.process_id = process_id
        self.alive = alive
        self.coordinator_id: Optional[int] = None
        self.log: List[str] = []

    def _log(self, msg: str) -> None:
        self.log.append(f"[P{self.process_id}] {msg}")


class RingElection:
    """
    Simula o algoritmo de eleição em anel. A ordem lógica do anel é
    dada pela ordem da lista `processes` (o último aponta de volta
    para o primeiro).
    """

    def __init__(self, processes: List[RingProcess]):
        self.ring: List[RingProcess] = processes

    def _next_alive(self, index: int) -> int:
        n = len(self.ring)
        nxt = (index + 1) % n
        # pula processos mortos até achar o próximo vivo
        while not self.ring[nxt].alive:
            nxt = (nxt + 1) % n
        return nxt

    def start_election(self, initiator_index: int) -> int:
        initiator = self.ring[initiator_index]
        initiator._log("detectou falha do coordenador e inicia ELEIÇÃO no anel")

        msg = RingElectionMessage(ids_collected=[initiator.process_id])
        current_index = self._next_alive(initiator_index)

        # a mensagem circula até voltar ao processo iniciador
        while current_index != initiator_index:
            proc = self.ring[current_index]
            proc._log(f"recebeu ELECTION com IDs coletados {msg.ids_collected}")
            msg.ids_collected.append(proc.process_id)
            proc._log(f"acrescenta seu ID -> repassa {msg.ids_collected}")
            current_index = self._next_alive(current_index)

        winner_id = max(msg.ids_collected)
        initiator._log(f"mensagem retornou; maior ID coletado = P{winner_id} -> vencedor")

        # circula o anúncio do coordenador por todo o anel
        announce_index = self._next_alive(initiator_index)
        initiator.coordinator_id = winner_id
        while announce_index != initiator_index:
            proc = self.ring[announce_index]
            proc.coordinator_id = winner_id
            proc._log(f"recebeu anúncio: novo coordenador é P{winner_id}")
            announce_index = self._next_alive(announce_index)

        return winner_id


# ------------------------------------------------------------------
# Demonstração
# ------------------------------------------------------------------
def demo_bully() -> None:
    print("=== Demonstração: Algoritmo do Valentão (Bully) ===")
    procs = [BullyProcess(pid) for pid in range(1, 7)]
    # simula queda do coordenador atual (P6) e de P5
    procs[5].alive = False  # P6 caiu (era o coordenador)
    procs[4].alive = False  # P5 também está fora

    election = BullyElection(procs)
    winner = election.start_election(initiator_id=2)  # P2 percebe a falha

    for p in procs:
        for entry in p.log:
            print(entry)
    print(f"\n>>> Coordenador eleito: P{winner}\n")


def demo_ring() -> None:
    print("=== Demonstração: Algoritmo do Anel (Ring) ===")
    ids_order = [3, 1, 4, 6, 2, 5]  # ordem lógica do anel (não precisa ser crescente)
    procs = [RingProcess(pid) for pid in ids_order]
    procs[3].alive = False  # P6 (índice 3 no anel) caiu

    election = RingElection(procs)
    winner = election.start_election(initiator_index=0)  # P3 inicia

    for p in procs:
        for entry in p.log:
            print(entry)
    print(f"\n>>> Coordenador eleito: P{winner}\n")


if __name__ == "__main__":
    demo_bully()
    demo_ring()
