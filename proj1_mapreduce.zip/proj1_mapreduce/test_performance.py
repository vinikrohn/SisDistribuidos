"""
Teste simples de desempenho: compara o tempo total do pipeline
MapReduce local variando o número de trabalhadores e o tamanho do chunk.

Não é um benchmark científico (o arquivo de exemplo é pequeno), mas serve
para demonstrar, de forma didática, o efeito de paralelizar o trabalho
entre múltiplos processos isolados.
"""
from log_analyzer import LogCoordinator

if __name__ == "__main__":
    configs = [
        (1, 200),   # 1 worker, chunk único (sequencial)
        (2, 50),
        (4, 20),
        (8, 10),
    ]

    print(f"{'workers':>8} | {'chunk_size':>10} | {'tempo (s)':>10} | {'linhas':>7}")
    print("-" * 45)
    for num_workers, chunk_size in configs:
        coordinator = LogCoordinator("erro.log", num_workers=num_workers, chunk_size=chunk_size)
        report = coordinator.run()
        print(f"{num_workers:>8} | {chunk_size:>10} | {report.total_time:>10.4f} | {report.total_lines:>7}")
