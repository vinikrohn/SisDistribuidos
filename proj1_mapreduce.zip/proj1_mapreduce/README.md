# Analisador de Logs Distribuído (MapReduce Local)

Trabalho de Sistemas Distribuídos — implementação de um pipeline **Map / Reduce**
local usando **processos** e **filas de mensagens**, sem uso de memória
compartilhada entre os trabalhadores.

## Arquitetura

```
                 ┌───────────────────────┐
 erro.log  ───▶  │      Coordinator       │
                 │  (lê e divide em       │
                 │   chunks)              │
                 └──────────┬─────────────┘
                             │ task_queue (mp.Queue)
                 ┌───────────┼───────────┬───────────┐
                 ▼           ▼           ▼           ▼
             Worker 0    Worker 1    Worker 2    Worker 3
          (processo)   (processo)  (processo)  (processo)
                 │           │           │           │
                 └───────────┴─────┬─────┴───────────┘
                                    │ result_queue (mp.Queue)
                                    ▼
                           Coordinator.reduce()
                                    │
                                    ▼
                           Relatório final agregado
```

- **Coordenador (`LogCoordinator`)**: lê `erro.log`, quebra o arquivo em
  pedaços (`ChunkTask`) de tamanho configurável e os distribui via
  `task_queue`.
- **Trabalhadores (`LogWorker`)**: cada um é um `multiprocessing.Process`
  independente. Consome tarefas da fila, processa isoladamente (sem
  acessar nenhuma variável do coordenador ou de outro worker) e devolve
  um `PartialSummary` pela `result_queue`.
- **Redução final**: o coordenador junta todos os `PartialSummary` em um
  `FinalReport` com contagem total de linhas, contagem por nível de log
  e contagem por usuário.

## Formato do log de entrada

```
data,hora,codigo,usuario
2026-08-26,08:00:00,0,sistema
```

O campo `codigo` não vem documentado no arquivo original, então foi
adotada a convenção usual de níveis de log:

| código | nível     |
|--------|-----------|
| 0      | INFO      |
| 1      | WARNING   |
| 2      | ERROR     |
| 3      | CRITICAL  |

## Como rodar

```bash
python3 log_analyzer.py         # roda o pipeline completo e imprime o relatório
python3 test_performance.py     # compara diferentes números de workers/chunk_size
```

## Por que isso é "sem memória compartilhada"?

Cada `LogWorker` é um **processo do sistema operacional** (não uma
thread), criado com `multiprocessing.Process`. Processos não
compartilham espaço de memória por padrão — a única forma de troca de
dados entre coordenador e workers é serializando mensagens
(`pickle`, feito automaticamente pelo `multiprocessing.Queue`) e
enviando pela fila. Isso simula, em uma única máquina, o comportamento
de nós distintos em um sistema distribuído real que só se comunicam por
troca de mensagens (ex.: RabbitMQ, Kafka, gRPC).
