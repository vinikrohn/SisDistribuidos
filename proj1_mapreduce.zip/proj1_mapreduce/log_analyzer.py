"""
Analisador de Logs Distribuído (MapReduce Local)
==================================================

Trabalho de Sistemas Distribuídos - Exercício 1

Cenário implementado:
- Um COORDENADOR lê um arquivo de log grande e o divide em pedaços (chunks).
- Os pedaços são enviados para um POOL DE TRABALHADORES (Worker) através de
  filas de mensagens (multiprocessing.Queue), simulando troca de mensagens
  entre processos distribuídos (sem memória compartilhada).
- Cada Worker roda em um PROCESSO próprio (não thread), processa seu pedaço
  de forma totalmente isolada e devolve um RESUMO PARCIAL (PartialSummary)
  através de outra fila.
- O Coordenador agrega (reduce) todos os resumos parciais em um resultado
  final e o exibe.

Formato do log (erro.log):
    data,hora,codigo,usuario
    2026-08-26,08:00:00,0,sistema

O campo "codigo" é o nível do evento. Convenção adotada (documentada no
relatório, pois o arquivo não traz um cabeçalho/legenda):
    0 -> INFO
    1 -> WARNING
    2 -> ERROR
    3 -> CRITICAL

Autor: (preencher com o nome do aluno antes de publicar no GitHub)
"""

from __future__ import annotations

import multiprocessing as mp
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Dict


# ----------------------------------------------------------------------
# Convenção de níveis de log usada no arquivo erro.log
# ----------------------------------------------------------------------
LEVEL_NAMES: Dict[str, str] = {
    "0": "INFO",
    "1": "WARNING",
    "2": "ERROR",
    "3": "CRITICAL",
}


# ----------------------------------------------------------------------
# Modelos de dados (mensagens trocadas entre coordenador e trabalhadores)
# ----------------------------------------------------------------------
@dataclass
class ChunkTask:
    """Mensagem enviada do Coordenador para um Worker: um pedaço do log."""
    chunk_id: int
    lines: List[str]


@dataclass
class PartialSummary:
    """Mensagem devolvida por um Worker ao Coordenador: resumo parcial."""
    chunk_id: int
    worker_pid: int
    total_lines: int = 0
    malformed_lines: int = 0
    level_counts: Dict[str, int] = field(default_factory=dict)
    user_counts: Dict[str, int] = field(default_factory=dict)
    processing_time: float = 0.0

    def as_dict(self) -> dict:
        return {
            "chunk_id": self.chunk_id,
            "worker_pid": self.worker_pid,
            "total_lines": self.total_lines,
            "malformed_lines": self.malformed_lines,
            "level_counts": self.level_counts,
            "user_counts": self.user_counts,
            "processing_time": round(self.processing_time, 4),
        }


# ----------------------------------------------------------------------
# Trabalhador (Worker)
# ----------------------------------------------------------------------
class LogWorker(mp.Process):
    """
    Um trabalhador isolado do pool.

    Regras seguidas (conforme enunciado):
    - Roda em um PROCESSO separado (não compartilha memória com o
      coordenador nem com os demais workers).
    - Só se comunica por FILAS DE MENSAGENS (task_queue / result_queue).
    - Não altera nenhuma variável global: todo o estado que produz fica
      encapsulado dentro do próprio método `run` e é devolvido como uma
      mensagem (PartialSummary).
    """

    def __init__(self, worker_id: int, task_queue: mp.Queue, result_queue: mp.Queue):
        super().__init__(name=f"LogWorker-{worker_id}")
        self.worker_id = worker_id
        self.task_queue = task_queue
        self.result_queue = result_queue

    def run(self) -> None:
        # Cada worker fica em loop consumindo tarefas da fila até receber
        # o sinal de encerramento (None) - o clássico "poison pill".
        while True:
            task = self.task_queue.get()
            if task is None:
                break
            summary = self._process_chunk(task)
            self.result_queue.put(summary)

    def _process_chunk(self, task: ChunkTask) -> PartialSummary:
        start = time.perf_counter()
        summary = PartialSummary(chunk_id=task.chunk_id, worker_pid=self.pid or 0)

        for raw_line in task.lines:
            line = raw_line.strip()
            if not line:
                continue

            parts = line.split(",")
            if len(parts) != 4:
                summary.malformed_lines += 1
                continue

            _date, _time, codigo, usuario = parts
            nivel = LEVEL_NAMES.get(codigo, f"DESCONHECIDO({codigo})")

            summary.level_counts[nivel] = summary.level_counts.get(nivel, 0) + 1
            summary.user_counts[usuario] = summary.user_counts.get(usuario, 0) + 1
            summary.total_lines += 1

        summary.processing_time = time.perf_counter() - start
        return summary


# ----------------------------------------------------------------------
# Coordenador
# ----------------------------------------------------------------------
class LogCoordinator:
    """
    Processo coordenador (Map + Reduce local).

    Responsabilidades:
    1. Ler o arquivo de log grande.
    2. Dividi-lo em pedaços (chunks) de tamanho configurável.
    3. Distribuir os pedaços para um pool de LogWorker via fila de tarefas.
    4. Coletar os resumos parciais via fila de resultados.
    5. Agregar (reduce) os resumos parciais em um resultado final único.
    """

    def __init__(self, log_path: str, num_workers: int = 4, chunk_size: int = 20):
        self.log_path = Path(log_path)
        self.num_workers = num_workers
        self.chunk_size = chunk_size

        self.task_queue: mp.Queue = mp.Queue()
        self.result_queue: mp.Queue = mp.Queue()
        self.workers: List[LogWorker] = []

    # -- Etapa 1 e 2: leitura e divisão do arquivo ---------------------
    def _split_into_chunks(self) -> List[ChunkTask]:
        with self.log_path.open("r", encoding="utf-8") as f:
            lines = f.readlines()

        chunks: List[ChunkTask] = []
        for chunk_id, i in enumerate(range(0, len(lines), self.chunk_size)):
            piece = lines[i:i + self.chunk_size]
            chunks.append(ChunkTask(chunk_id=chunk_id, lines=piece))
        return chunks

    # -- Etapa 3: inicia o pool de trabalhadores -----------------------
    def _start_workers(self) -> None:
        for wid in range(self.num_workers):
            worker = LogWorker(wid, self.task_queue, self.result_queue)
            worker.start()
            self.workers.append(worker)

    def _stop_workers(self) -> None:
        # Envia uma "poison pill" para cada worker, sinalizando o fim.
        for _ in self.workers:
            self.task_queue.put(None)
        for worker in self.workers:
            worker.join()

    # -- Orquestração completa ------------------------------------------
    def run(self) -> "FinalReport":
        start_total = time.perf_counter()

        chunks = self._split_into_chunks()
        self._start_workers()

        for chunk in chunks:
            self.task_queue.put(chunk)

        partial_summaries: List[PartialSummary] = []
        for _ in chunks:
            partial_summaries.append(self.result_queue.get())

        self._stop_workers()

        total_time = time.perf_counter() - start_total
        return self._reduce(partial_summaries, len(chunks), total_time)

    # -- Etapa 5: reduce final -------------------------------------------
    def _reduce(self, summaries: List[PartialSummary], num_chunks: int, total_time: float) -> "FinalReport":
        report = FinalReport(num_chunks=num_chunks, num_workers=self.num_workers, total_time=total_time)
        for s in sorted(summaries, key=lambda x: x.chunk_id):
            report.merge(s)
        return report


# ----------------------------------------------------------------------
# Resultado final agregado
# ----------------------------------------------------------------------
@dataclass
class FinalReport:
    num_chunks: int
    num_workers: int
    total_time: float
    total_lines: int = 0
    malformed_lines: int = 0
    level_counts: Dict[str, int] = field(default_factory=dict)
    user_counts: Dict[str, int] = field(default_factory=dict)
    per_chunk: List[dict] = field(default_factory=list)

    def merge(self, s: PartialSummary) -> None:
        self.total_lines += s.total_lines
        self.malformed_lines += s.malformed_lines
        for nivel, qtd in s.level_counts.items():
            self.level_counts[nivel] = self.level_counts.get(nivel, 0) + qtd
        for usuario, qtd in s.user_counts.items():
            self.user_counts[usuario] = self.user_counts.get(usuario, 0) + qtd
        self.per_chunk.append(s.as_dict())

    def print_report(self) -> None:
        print("=" * 60)
        print("RELATÓRIO FINAL - ANALISADOR DE LOGS DISTRIBUÍDO")
        print("=" * 60)
        print(f"Chunks processados : {self.num_chunks}")
        print(f"Workers utilizados : {self.num_workers}")
        print(f"Tempo total        : {self.total_time:.4f}s")
        print(f"Linhas processadas : {self.total_lines}")
        print(f"Linhas malformadas : {self.malformed_lines}")
        print("-" * 60)
        print("Contagem por nível de log:")
        for nivel, qtd in sorted(self.level_counts.items(), key=lambda x: -x[1]):
            print(f"  {nivel:<12}: {qtd}")
        print("-" * 60)
        print("Contagem por usuário:")
        for usuario, qtd in sorted(self.user_counts.items(), key=lambda x: -x[1]):
            print(f"  {usuario:<12}: {qtd}")
        print("=" * 60)


# ----------------------------------------------------------------------
# Execução direta (demo)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    coordinator = LogCoordinator(log_path="erro.log", num_workers=4, chunk_size=20)
    final_report = coordinator.run()
    final_report.print_report()
